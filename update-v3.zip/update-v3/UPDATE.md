# Update v3 – kompletter aktueller Stand

Enthält alles aus Update v2 (mehr Bewegung, Sounds, Hook-Einschlag) plus:

- **CLAUDE.md** komplett neu: Stand der Folgen, Regeln für Aufmerksamkeit und Bewegung, Hook-Regeln mit Du-Ansprache, fester Ablauf für jede neue Folge, Sounds, Hinweise zum Hochladen.
- **src/folgen/folge-01.json:** neuer Hook („Warum rastet DEIN Kind sofort aus?“) und Altersangaben in Szene 3 und 4.
- **src/folgen/folge-03.json:** Skript-Entwurf für Folge 3 nach den neuen Hook-Regeln.
- **HighlightText.tsx:** Satzzeichen bleiben mit dem gelben Marker in einer Zeile.

## Dateien

| Datei | Hinweis |
|---|---|
| `package.json`, `package-lock.json` | neues Paket `@remotion/paths` |
| `CLAUDE.md` | ersetzt die alte Version |
| `src/brand.ts` | `SOUNDS`, `LAUTSTAERKE` – eigene Sound-Pfade danach wieder eintragen |
| `src/types.ts` | Grafik `handy` |
| `src/Folge.tsx` | Fortschrittsbalken, Wusch, Übergänge |
| `src/components/*.tsx` | Animationen, Marker, Untertitel, Sounds |
| `src/szenen/Szenen.tsx` | alle Szenen, Hook-Einschlag |
| `src/folgen/folge-01.json` | ersetzt Folge 1 (alte Audio-Einträge fallen weg, Stimme wird neu erzeugt) |
| `src/folgen/folge-03.json` | neu, muss noch in `src/folgen/index.ts` eingetragen werden |
| `public/sfx/*.mp3` | einfache Start-Sounds ohne Urheberrecht |

Nicht enthalten und nicht anfassen: `src/folgen/index.ts` (nur Folge 3 ergänzen), `src/folgen/folge-02.json`, `public/audio/`, `scripts/`, `src/Root.tsx`, `src/Cover.tsx`.
