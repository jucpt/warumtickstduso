import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { FARBEN } from '../brand';
import { GrafikName } from '../types';
import { Gehirn } from './Gehirn';

// Linien-Grafiken im Logo-Stil: runde Enden, einheitliche Strichstärke.
// Regel: Jede Grafik zeichnet sich erst selbst und bewegt sich danach DAUERHAFT weiter
// (Impulse, Pulsieren, Fließen) – es gibt keinen Moment, in dem das Bild still steht.
// Neue Grafiken hier ergänzen und in types.ts bei GrafikName eintragen.

const useZeit = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return { frame, fps, t: frame / fps };
};

const useZeichnen = (dauerSek = 1.2, startSek = 0.1) => {
  const { frame, fps } = useZeit();
  return interpolate(frame, [startSek * fps, (startSek + dauerSek) * fps], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
};

const SVG: React.FC<{ groesse: number; children: React.ReactNode }> = ({ groesse, children }) => (
  <svg width={groesse} height={groesse} viewBox="0 0 200 200" fill="none" strokeLinecap="round" strokeLinejoin="round" style={{ overflow: 'visible' }}>
    {children}
  </svg>
);

const HERZ = 'M100 160 C60 130 36 106 36 80 C36 60 52 46 70 46 C84 46 94 54 100 64 C106 54 116 46 130 46 C148 46 164 60 164 80 C164 106 140 130 100 160 Z';

// Gefühl, das ansteigt und weiterfließt
const Welle: React.FC<{ groesse: number }> = ({ groesse }) => {
  const { t } = useZeit();
  const p = useZeichnen(1.2);
  const anstieg = interpolate(t, [0, 3], [0.55, 1], { extrapolateRight: 'clamp' });
  const punkte: [number, number][] = [];
  for (let x = 20; x <= 180; x += 2) {
    const amp = (4 + ((x - 20) / 160) ** 1.6 * 52) * anstieg;
    const y = 110 - amp * Math.sin((x - 20) / 9 - t * 4);
    punkte.push([x, y]);
  }
  const ende = punkte[punkte.length - 1];
  return (
    <SVG groesse={groesse}>
      <line x1="20" y1="172" x2="180" y2="172" stroke={FARBEN.neben} strokeWidth={5} opacity={0.5} />
      <polyline
        points={punkte.map(([x, y]) => `${x},${y.toFixed(1)}`).join(' ')}
        stroke={FARBEN.akzent}
        strokeWidth={7}
        pathLength={1}
        strokeDasharray={1}
        strokeDashoffset={1 - p}
      />
      <g opacity={p >= 1 ? 1 : 0}>
        <circle cx={ende[0]} cy={ende[1]} r={14} fill={FARBEN.highlight} opacity={0.25} />
        <circle cx={ende[0]} cy={ende[1]} r={7} fill={FARBEN.highlight} />
      </g>
    </SVG>
  );
};

// Sprechblase, in der die Worte „hängen“
const Sprechblase: React.FC<{ groesse: number }> = ({ groesse }) => {
  const { t, frame, fps } = useZeit();
  const p = useZeichnen(0.9);
  const schweben = Math.sin(t * 2) * 4;
  return (
    <SVG groesse={groesse}>
      <g transform={`translate(0 ${schweben})`}>
        <path
          d="M40 50 H160 Q176 50 176 66 V122 Q176 138 160 138 H92 L64 164 L70 138 H40 Q24 138 24 122 V66 Q24 50 40 50 Z"
          stroke={FARBEN.neben}
          strokeWidth={7}
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - p}
        />
        {[0, 1, 2].map((i) => {
          const da = spring({ frame: frame - (0.9 + i * 0.15) * fps, fps, config: { damping: 12 } });
          const huepfen = Math.max(0, Math.sin(2 * Math.PI * (t * 1.4 - i * 0.18))) * 12;
          return <circle key={i} cx={70 + i * 30} cy={94 - huepfen * da} r={9 * da} fill={FARBEN.akzent} />;
        })}
      </g>
    </SVG>
  );
};

// Herz mit Doppelschlag und Ringen, die nach außen laufen
const Herz: React.FC<{ groesse: number }> = ({ groesse }) => {
  const { t } = useZeit();
  const p = useZeichnen(1.1);
  const takt = t % 1;
  const schlag = Math.exp(-((takt - 0.05) ** 2) / 0.002) + 0.7 * Math.exp(-((takt - 0.3) ** 2) / 0.002);
  const fertig = p >= 1 ? 1 : 0;
  const skala = 1 + 0.08 * schlag * fertig;
  const ringe = [0, 0.5].map((v) => ((t + v) % 1));
  return (
    <SVG groesse={groesse}>
      {fertig
        ? ringe.map((r, i) => (
            <path
              key={i}
              d={HERZ}
              stroke={FARBEN.akzent}
              strokeWidth={4}
              opacity={(1 - r) * 0.5}
              transform={`translate(100 105) scale(${1 + r * 0.6}) translate(-100 -105)`}
            />
          ))
        : null}
      <g transform={`translate(100 105) scale(${skala}) translate(-100 -105)`}>
        <path d={HERZ} stroke={FARBEN.akzent} strokeWidth={7} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
      </g>
    </SVG>
  );
};

// Gehirn mit markiertem Stirnhirn (der „Bremse“)
const GehirnVorne: React.FC<{ groesse: number }> = ({ groesse }) => {
  const { t, frame, fps } = useZeit();
  const p = useZeichnen(1.3);
  const leuchten = interpolate(frame, [1.3 * fps, 1.8 * fps], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const puls = 0.5 + 0.5 * Math.sin(t * Math.PI * 1.4);
  return (
    <Gehirn groesse={groesse} fortschritt={p} impulse anzahlImpulse={4}>
      <ellipse
        cx="100"
        cy="60"
        rx={54 + puls * 8}
        ry={26 + puls * 4}
        stroke={FARBEN.highlight}
        strokeWidth={5}
        strokeDasharray="10 12"
        strokeDashoffset={-t * 30}
        opacity={leuchten}
      />
    </Gehirn>
  );
};

const GehirnGross: React.FC<{ groesse: number }> = ({ groesse }) => {
  const p = useZeichnen(1.3);
  return <Gehirn groesse={groesse} fortschritt={p} impulse />;
};

// Handy mit endlosem Feed und wischendem Daumen
const Handy: React.FC<{ groesse: number }> = ({ groesse }) => {
  const { t } = useZeit();
  const p = useZeichnen(0.9);
  const da = p >= 1 ? 1 : 0;
  const versatz = (t * 46) % 42;
  const wisch = (t % 0.9) / 0.9;
  return (
    <SVG groesse={groesse}>
      <defs>
        <clipPath id="bildschirm">
          <rect x="70" y="34" width="60" height="132" rx="6" />
        </clipPath>
      </defs>
      <g clipPath="url(#bildschirm)" opacity={da}>
        {Array.from({ length: 5 }).map((_, i) => {
          const y = 36 + i * 42 - versatz;
          return (
            <g key={i}>
              <rect x="74" y={y} width="52" height="34" rx="6" stroke={FARBEN.akzent} strokeWidth={4} />
              <line x1="82" y1={y + 24} x2={i % 2 ? 104 : 114} y2={y + 24} stroke={FARBEN.neben} strokeWidth={4} opacity={0.7} />
            </g>
          );
        })}
      </g>
      <rect x="62" y="20" width="76" height="160" rx="16" stroke={FARBEN.neben} strokeWidth={7} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
      <line x1="90" y1="27" x2="110" y2="27" stroke={FARBEN.neben} strokeWidth={4} opacity={p} />
      <g opacity={da * Math.sin(Math.PI * wisch)}>
        <circle cx={156} cy={150 - wisch * 80} r={14} fill={FARBEN.highlight} opacity={0.25} />
        <circle cx={156} cy={150 - wisch * 80} r={7} fill={FARBEN.highlight} />
      </g>
    </SVG>
  );
};

export const Grafik: React.FC<{ name?: GrafikName; groesse?: number }> = ({ name = 'keine', groesse = 520 }) => {
  const { frame, fps, t } = useZeit();
  if (!name || name === 'keine') return null;
  const auftritt = spring({ frame, fps, config: { damping: 13, mass: 0.7 } });
  const schweben = Math.sin(t * 1.3) * 6;
  const inhalt = (() => {
    switch (name) {
      case 'gehirn':
        return <GehirnGross groesse={groesse} />;
      case 'gehirn-vorne':
        return <GehirnVorne groesse={groesse} />;
      case 'welle':
        return <Welle groesse={groesse} />;
      case 'sprechblase':
        return <Sprechblase groesse={groesse} />;
      case 'herz':
        return <Herz groesse={groesse} />;
      case 'handy':
        return <Handy groesse={groesse} />;
      default:
        return null;
    }
  })();
  return <div style={{ transform: `translateY(${schweben}px) scale(${0.6 + 0.4 * auftritt})` }}>{inhalt}</div>;
};
